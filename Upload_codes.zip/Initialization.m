function [fac_pi,fac_Cmax,fac_D] = Initialization(n,f,fac_m,fac_r,fac_pij,fac_s)
pj=zeros(n,2);
fac_Cmax=zeros(f,1);
fac_pi=cell(f,1);
fac_D=cell(f,1);
for j=1:n
    pj(j,1)=j;
    for l=1:f
        pij=fac_pij{l,1};
        pj(j,2)=pj(j,2)+sum(pij(:,j),1);
    end
end
f_r=zeros(f,2);
for l=1:f
    f_r(l,1)=l;
    f_r(l,2)=fac_r{l,1};
end
pj=sortrows(pj,-2);
f_r=sortrows(f_r,2);
pi=zeros(1,n);
pi=pj(:,1)';
for j=1:f
    fac_pi{f_r(j,1),1}=pi(1,j);
    [fac_Cmax(f_r(j,1),1),fac_D{f_r(j,1),1}]=problem(f_r(j,1),fac_m,fac_r,fac_pij,fac_s,pi(1,j));
end
for j=f+1:n 
    current_pi=cell(f,3);
    for l=1:f
        pi_f=fac_pi{l,1};
        index=zeros(size(pi_f,2)+1,size(pi_f,2)+1);
        index_Cmax=zeros(size(pi_f,2)+1,1);
        index_D=cell(size(pi_f,2)+1,1);
        min_Cmax=inf;
        for pos_i=1:size(pi_f,2)+1
            t=1;
            for pos_j=1:size(pi_f,2)+1
                if pos_j==pos_i
                   index(pos_i,pos_j)=pi(1,j);
                else
                   index(pos_i,pos_j)=pi_f(1,t);
                   t=t+1;
                end
            end
            [index_Cmax(pos_i,1),index_D{pos_i,1}]=problem(l,fac_m,fac_r,fac_pij,fac_s,index(pos_i,:));
            if index_Cmax(pos_i,1)<=min_Cmax
                min_Cmax=index_Cmax(pos_i,1);
                min_pos=pos_i;
            end
        end
        current_pi{l,1}=index(min_pos,:);
        current_pi{l,2}=min_Cmax;
        current_pi{l,3}=index_D{min_pos,1};
    end   
    min_Cmax_f=inf;
    for l=1:f
        if current_pi{l,2}<=min_Cmax_f
            min_Cmax_f=current_pi{l,2};
            best_pos_f=l;
        end
    end
    fac_pi{best_pos_f,1}=current_pi{best_pos_f,1};
    fac_Cmax(best_pos_f,1)=current_pi{best_pos_f,2};
    fac_D{best_pos_f,1}=current_pi{best_pos_f,3};
end
end

