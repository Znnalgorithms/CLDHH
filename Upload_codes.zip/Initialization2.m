function [fac_pi,fac_Cmax,fac_D] = Initialization2(f,n,fac_m,fac_r,fac_pij,fac_s,fac_pi,pi)
fac_Cmax=zeros(f,1);
fac_D=cell(f,1);
current_pi=zeros(f,2);
f_r=zeros(f,2);
for l=1:f
    current_pi(l,1)=pi(1,l);
    for f_num=1:f
        pij=fac_pij{f_num,1};
        current_pi(l,2)=current_pi(l,2)+sum(pij(:,pi(1,l)),1);
    end
    f_r(l,1)=l;
    f_r(l,2)=fac_r{l,1};
end
current_pi=sortrows(current_pi,-2);
f_r=sortrows(f_r,2);
    for i=1:n
        if i<=f
            fac_pi{f_r(i,1),1}=current_pi(i,1);
            [fac_Cmax(f_r(i,1),1),fac_D{f_r(i,1),1}]=problem(f_r(i,1),fac_m,fac_r,fac_pij,fac_s,current_pi(i,1));
%             fac_pi{i,1}=pi(1,i);
%             [fac_Cmax(i,1),fac_D{i,1}]=problem(i,fac_m,fac_r,fac_pij,fac_s,pi(1,i));
        else
            index=cell(f,1);
            index_D=cell(f,1);
            index_Cmax=zeros(f,1);
            for j=1:f
                index{j,1}=[fac_pi{j,1},pi(1,i)];
                [index_Cmax(j,1),index_D{j,1}]=problem(j,fac_m,fac_r,fac_pij,fac_s,index{j,1});
            end
            %current_fac_Cmax=problem(f,fac_m,fac_r,fac_pij,fac_s,index);
            min=inf;
            for j=1:f
                if index_Cmax(j,1)<=min
                   min=index_Cmax(j,1);
                   min_f=j;
                end
            end
                %fac_pi{min_f,1}=[fac_pi{min_f,1},pi(1,i)];
                fac_pi{min_f,1}=index{min_f,1};
                fac_Cmax(min_f,1)=index_Cmax(min_f,1);
                fac_D{min_f,1}=index_D{min_f,1};
        end
    end
end

