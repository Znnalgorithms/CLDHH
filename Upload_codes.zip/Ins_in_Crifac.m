function [fac_pi,fac_Cmax,fac_D,Q_table] = Ins_in_Crifac(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table)
    Crifac_max=0;
    for f_num=1:f
        if fac_Cmax(f_num,1)>=Crifac_max
            Crifac_max=fac_Cmax(f_num,1);
            Crifac=f_num;
        end
    end
    pi_f=fac_pi{Crifac,1};
    fc=pi_f;
    if size(fc,2)~=1
       k_position=floor(size(fc,2)*rand)+1;
       j_position=floor(size(fc,2)*rand)+1;
       while j_position==k_position
          j_position=floor(size(fc,2)*rand)+1;
       end
       j=fc(1,j_position);
       if k_position>j_position
          for i=j_position:k_position-1
              fc(1,i)=fc(1,i+1); 
          end
          fc(1,k_position)=j;
       else
          for i=j_position-1:-1:k_position
              fc(1,i+1)=fc(1,i); 
          end
          fc(1,k_position)=j;
       end
%        j_position
%        k_position
%        fc
       %Cmax = problem(Crifac,fac_m,fac_r,fac_pij,fac_s,fc);
       [Cmax,D_f] = Speedup(Crifac,fac_m,fac_r,fac_pij,fac_s,fc,fac_D,pi_f);
%        fac_Cmax(Crifac,1)
%        Cmax
       if Cmax<fac_Cmax(Crifac,1)
          fac_pi{Crifac,1}=fc;
          fac_Cmax(Crifac,1)=Cmax;
          fac_D{Crifac,1}=D_f;
%           Q_table(1,2)=Q_table(1,2)+aw;
          Q_table(1,3)=Q_table(1,3)+1;
       else
%           if Q_table(1,2)>0
%              Q_table(1,2)=Q_table(1,2)-pun;
%           end
          Q_table(1,4)=Q_table(1,4)+1;
       end
       Q_table(1,2)=Q_table(1,2)+Q_table(1,3)/(Q_table(1,3)+Q_table(1,4));   
    end
end

