clc,clear
for sdst=125
d=1;
run_number=5;
data=zeros(240,run_number+1);
count_data=zeros(240,run_number+1);
for f=2:5 %f={2,3,4,5};
% d=1;
for m=[5,10,20] %m={5,10,20};
for n=[20,50,80,100,200] %n={20 50 100 200 500};
for num=1:4
filename=['problem\test suite\test_',num2str(f),'_',num2str(m),'_',num2str(n),'_',num2str(sdst),'_',num2str(num),'.txt'];
% filename=['test_',num2str(f),'_',num2str(m),'_',num2str(n),'_',num2str(sdst),'_',num2str(num),'.txt'];
instance=textread(filename);
fprintf('test:%s\n',filename);

[f,n,fac_m,fac_r,fac_pij,fac_s]=read_test(instance);
runtime=f*m*n*30*10^(-3);
for run_num=1:run_number
%%

PS=3;
ratio=1;
b_length=4;
X=zeros(PS,n);   
fac_ps=cell(PS,1);
fac_ps_Cmax=cell(PS,1);
fac_ps_D=cell(PS,1);
min_Cmax=inf;
for ps=1:PS
    X(ps,:)=randperm(n);
    pi=zeros(1,n);
    pi(1,:)=X(ps,:);
    fac_pi=cell(f,1);
    fac_ps_D=cell(PS,1);
    
    if ps==1
       [fac_pi,fac_Cmax,fac_D] = Initialization(n,f,fac_m,fac_r,fac_pij,fac_s);
    else
%        ps_rand=floor(2*rand)+1;
%        if ps_rand==1
%           [fac_pi,fac_Cmax,fac_D] = Initialization1(f,n,fac_m,fac_r,fac_pij,fac_s,fac_pi,pi,b_length,ratio);
%        end
%       if ps_rand==2
        [fac_pi,fac_Cmax,fac_D] = Initialization2(f,n,fac_m,fac_r,fac_pij,fac_s,fac_pi,pi);
%        end
    end
    fac_ps{ps,1}=fac_pi;
    fac_ps_Cmax{ps,1}=fac_Cmax;
    fac_ps_D{ps,1}=fac_D;
    Cmax=max(fac_Cmax);
    if Cmax<=min_Cmax
        min_Cmax=Cmax;
    end
end

NS=10;                         
SN=5;
Q_table=zeros(NS,4);
for ns=1:NS
    Q_table(ns,1)=ns;
end

count=0;       
tic                           
run_end=toc;
while run_end<=runtime

% aw=1;
% pun=0;
for ps=1:PS
    fac_pi=fac_ps{ps,1};
    fac_Cmax=fac_ps_Cmax{ps,1};
    fac_D=fac_ps_D{ps,1};
    for sn=1:SN
        [fac_pi,fac_Cmax,fac_D,Q_table] = Ins_in_Crifac(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table);
        [fac_pi,fac_Cmax,fac_D,Q_table] = Swa_in_Crifac(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table);
        [fac_pi,fac_Cmax,fac_D,Q_table] = Swa_bet_Crifac(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table);
        [fac_pi,fac_Cmax,fac_D,Q_table] = Ins_bet_Crifac(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table);
        [fac_pi,fac_Cmax,fac_D,Q_table] = smallneighborins(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table);
        [fac_pi,fac_Cmax,fac_D,Q_table] = smallneighborswa(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table);
        [fac_pi,fac_Cmax,fac_D,Q_table] = largeneighborswa(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table);
        [fac_pi,fac_Cmax,fac_D,Q_table] = largeneighborins(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table);
        [fac_pi,fac_Cmax,fac_D,Q_table] = pr(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,b_length,Q_table,ratio);
        [fac_pi,fac_Cmax,fac_D,Q_table] = exploitation(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,b_length,Q_table,ratio);
    end
%     [fac_pi,fac_Cmax,fac_D] = localsearch(f,n,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,b_length);
    fac_ps{ps,1}=fac_pi;
    fac_ps_Cmax{ps,1}=fac_Cmax;
    fac_ps_D{ps,1}=fac_D;
end
% Q_table

% sum_Qtable=sum(Q_table);
% for ns=1:NS
%     p(ns,1)=Q_table(ns,1)/sum_Qtable;
% end
% aw=2;
% pun=1;
% % aw=1;
% % pun=0;
for ps=1:PS
    fac_pi=fac_ps{ps,1};
    fac_Cmax=fac_ps_Cmax{ps,1};
    fac_D=fac_ps_D{ps,1};
    for sn=1:SN
%     score=sortrows(Q_table,-2);
%     r=floor((NS/2)*rand)+1;
%     k=score(r,1);
    k=Selection(Q_table);
    [fac_pi,fac_Cmax,fac_D,Q_table] =hyperheuristic(k,f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table,b_length,ratio);
    end
%     [fac_pi,fac_Cmax,fac_D] = localsearch(f,n,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,b_length);
    fac_ps{ps,1}=fac_pi;
    fac_ps_Cmax{ps,1}=fac_Cmax;
    fac_ps_D{ps,1}=fac_D;
    Cmax=max(fac_Cmax);
    if Cmax<=min_Cmax
        min_Cmax=Cmax;
        min=ps;
    end
end

    fac_pi=fac_ps{min,1};
    fac_Cmax=fac_ps_Cmax{min,1};
    fac_D=fac_ps_D{min,1};
    for sn=1:SN
    score=sortrows(Q_table,-2);
    k=score(1,1);
    [fac_pi,fac_Cmax,fac_D,Q_table] = hyperheuristic(k,f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table,b_length,ratio);
%         [fac_pi,fac_Cmax,fac_D] = localsearch(f,n,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,b_length);
    end
    fac_ps{min,1}=fac_pi;
    fac_ps_Cmax{min,1}=fac_Cmax;
    fac_ps_D{min,1}=fac_D;

run_end=toc;
count=count+1;
% Q_table
end

for ps=1:PS
    fac_Cmax=fac_ps_Cmax{ps,1};
    Cmax=max(fac_Cmax);
    if Cmax<=min_Cmax
        min_Cmax=Cmax;
        min=ps;
    end
end
% min_Cmax
data(d,run_num)=min_Cmax;
count_data(d,run_num)=count;
end
data(d,run_number+1)=mean(data(d,1:run_number));
fprintf('mean = %f',data(d,run_number+1));
fprintf('\n---------------------------------------------------------------------------------\n');
count_data(d,run_number+1)=mean(count_data(d,1:run_number));
d=d+1;
if sdst==10
   xlswrite('data_CLDHH_10.xlsx',data,'sheet1');
   xlswrite('count_CLDHH_10.xlsx',count_data,'sheet1');
end
if sdst==50
   xlswrite('data_CLDHH_50.xlsx',data,'sheet1');
   xlswrite('count_CLDHH_50.xlsx',count_data,'sheet1');
end
if sdst==100
   xlswrite('data_CLDHH_100.xlsx',data,'sheet1');
   xlswrite('count_CLDHH_100.xlsx',count_data,'sheet1');
end
if sdst==125
   xlswrite('data_CLDHH_125.xlsx',data,'sheet1');
   xlswrite('count_CLDHH_125.xlsx',count_data,'sheet1');
end

%     if f==2
% xlswrite('data_CLDHH_10_2.xlsx',data,'sheet1');
% xlswrite('count_CLDHH_10_2.xlsx',count_data,'sheet1');
%     end
%     if f==3
% xlswrite('data_CLDHH_10_3.xlsx',data,'sheet1');
% xlswrite('count_CLDHH_10_3.xlsx',count_data,'sheet1');
%     end
%     if f==4
% xlswrite('data_CLDHH_10_4.xlsx',data,'sheet1');
% xlswrite('count_CLDHH_10_4.xlsx',count_data,'sheet1');
%     end
%     if f==5
% xlswrite('data_CLDHH_10_5.xlsx',data,'sheet1');
% xlswrite('count_CLDHH_10_5.xlsx',count_data,'sheet1');
%     end

end
end
end
end
end