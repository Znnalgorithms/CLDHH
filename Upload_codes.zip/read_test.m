function [f,n,fac_m,fac_r,fac_pij,fac_s]=read_test(instance)
f=instance(1,1);                        
fac_m=cell(f,1);                       
% % sum_fac_m=0;
for i=1:f
    fac_m{i,1}=instance(2,i);
% %     sum_fac_m=sum_fac_m+instance(2,i);  
end
n=instance(3,1);                         
fac_r=cell(f,1);
for i=1:f
    fac_r{i,1}=instance(4,i);           
end
fac_pij=cell(f,1);
index=5;
% % t=1;
% % pij=zeros(0,0);
% % for i=5:5+sum_fac_m-1
% %     if i<index+fac_m{t,1}-1
% %         pij=[pij;instance(i,:)];
% %     else
% %         pij=[pij;instance(i,:)];
% %         fac_pij{t,1}=pij;
% %         pij=zeros(0,0);
% %         index=index+fac_m{t,1};
% %         t=t+1;
% %     end  
% % end
for f_num=1:f
    pij=zeros(0,0);
    for i=index:index+fac_m{f_num,1}-1
        pij=[pij;instance(i,:)];
    end
    index=index+fac_m{f_num,1};
    fac_pij{f_num,1}=pij;
end
fac_s=cell(f,1);
for f_num=1:f
    current_fac_s=cell(fac_m{f_num,1},1);
    for m=1:fac_m{f_num,1}
        s=zeros(0,0);
        for i=index:index+n
            s=[s;instance(i,:)];
        end
        index=index+n+1;
        current_fac_s{m,1}=s;
    end
    fac_s{f_num,1}=current_fac_s;
end
end