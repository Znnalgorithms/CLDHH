function [fac_pi,fac_Cmax,fac_D] = Initialization_2(f,n,fac_m,fac_r,fac_pij,fac_s,fac_pi,pi,b_length,ratio)
[fac_pi,fac_Cmax,fac_D] = Initialization2(f,n,fac_m,fac_r,fac_pij,fac_s,fac_pi,pi);
for l=1:f
%     fac_D{l,1}
    s=fac_s{l,1};
    pi_f=fac_pi{l,1};
%     pi_f
    nl=size(pi_f,2);
    if nl~=1
       p=floor(nl*ratio)-floor((nl/2)*rand)+1;
%        p
       Cmax=fac_Cmax(l,1);
       for i=1:p
           b=floor(b_length*rand)+1;
           if b>=nl
              b=nl-1;
           end
%            b
           all_remove_pos=nl-b+1;
           remove_pos=floor(all_remove_pos*rand)+1;
%            remove_pos
           tau_b=[];
           tau_pi=[];
           for j=1:nl
               if j>=remove_pos&&j<=remove_pos+b-1
                   tau_b=[tau_b,pi_f(1,j)];
               else
                   tau_pi=[tau_pi,pi_f(1,j)];
               end
           end
%            tau_b
%            tau_pi
           tau_pos=zeros(size(tau_pi,2)+1,2);
           index=zeros(size(tau_pi,2)+1,nl);
           select_r=floor(3*rand)+1;
           for pos=1:size(tau_pi,2)+1
               s1=zeros(fac_m{l,1},1);
               s2=zeros(fac_m{l,1},1);
               s3=zeros(fac_m{l,1},1);
               index_pi=[];
               for j=1:size(tau_pi,2)+1
                   if j<pos
                       index_pi=[index_pi,tau_pi(1,j)];
                   end
                   if j==pos
                       index_pi=[index_pi,tau_b];
                   end
                   if j>pos
                       index_pi=[index_pi,tau_pi(1,j-1)];
                   end
               end
               for m=1:fac_m{l,1}
                   current_fac_s=s{m,1};
                   if pos==1
                      s1(m,1)=current_fac_s(1,(index_pi(1,pos)));
                   else
                      s1(m,1)=current_fac_s((index_pi(1,pos-1)+1),(index_pi(1,pos)));
                   end           
                   if pos==size(tau_pi,2)+1
                      s2=current_fac_s((index_pi(1,pos-1)+1),(index_pi(1,pos)));
                   else
                      s2(m,1)=current_fac_s((index_pi(1,pos+b-1)+1),(index_pi(1,pos+b)));
                   end
                   s3=s1+s2;
               end
%                index_pi
%                s3
               index(pos,:)=index_pi;
               if select_r==1
                   tau_pos(pos,1)=max(s1);
               end
               if select_r==2
                   tau_pos(pos,1)=max(s2);
               end
               if select_r==3
                   tau_pos(pos,1)=max(s3);
               end
               tau_pos(pos,2)=pos;
           end
%            index
%            tau_pos
           tau_pos=sortrows(tau_pos,1);
%            tau_ps
           for k=1:p
               if k<=size(tau_pi,2)+1
%                   [current_Cmax,D_f]=Single_DHNWFSP_SDST_Cmax(l,fac_m,fac_r,fac_pij,fac_s,index(tau_pos(k,2),:));
                  [current_Cmax,D_f] = Speedup(l,fac_m,fac_r,fac_pij,fac_s,index(tau_pos(k,2),:),fac_D,pi_f);
%                   current_Cmax
                  if current_Cmax<=Cmax
                     Cmax=current_Cmax;
                     fac_pi{l,1}=index(tau_pos(k,2),:);
                     fac_Cmax(l,1)=current_Cmax;
                     fac_D{l,1}=D_f;
                  end
               end
               pi_f=fac_pi{l,1}; 
           end

%            pi_f
       end

    
    end

end
end

