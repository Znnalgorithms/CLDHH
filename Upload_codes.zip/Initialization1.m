function [fac_pi,fac_Cmax,fac_D] = Initialization1(f,n,fac_m,fac_r,fac_pij,fac_s,fac_pi,pi)
fac_Cmax=zeros(f,1);
fac_D=cell(f,1);
    for i=1:n
        if i<=f
            fac_pi{i,1}=pi(1,i);
            [fac_Cmax(i,1),fac_D{i,1}]=problem(i,fac_m,fac_r,fac_pij,fac_s,pi(1,i));
        else
            min=inf;
            for j=1:f
                if fac_Cmax(j,1)<=min
                   min=fac_Cmax(j,1);
                   min_f=j;
                end
            end
            fac_pi{min_f,1}=[fac_pi{min_f,1},pi(1,i)];
            current_pi=fac_pi{min_f,1};     
            [fac_Cmax(min_f,1),fac_D{min_f,1}]=problem(min_f,fac_m,fac_r,fac_pij,fac_s,current_pi);
        end
    end
end

