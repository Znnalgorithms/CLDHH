function [fac_pi,fac_Cmax,fac_D,Q_table] = Swa_bet_Crifac(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table)
    Crifac_max=0;
    for f_num=1:f
        if fac_Cmax(f_num,1)>=Crifac_max
            Crifac_max=fac_Cmax(f_num,1);
            Crifac=f_num;
        end
    end
    pi_fc=fac_pi{Crifac,1};
    fc=pi_fc;
    f_rand=floor(f*rand)+1;
    while f_rand==Crifac
       f_rand=floor(f*rand)+1;
    end
    pi_fr=fac_pi{f_rand,1};
    fr=pi_fr;
%     fc
%     fr
    j_position=floor(size(fc,2)*rand)+1;
    k_position=floor(size(fr,2)*rand)+1;
%     j_position
%     k_position
    j=fc(1,j_position);
    k=fr(1,k_position);
    fc(1,j_position)=k;
    fr(1,k_position)=j;
%     fc
%     fr
%     Cmax_fc = Single_DHNWFSP_SDST_Cmax(Crifac,fac_m,fac_r,fac_pij,fac_s,fc);
     [Cmax_fc,D_fc] = Speedup(Crifac,fac_m,fac_r,fac_pij,fac_s,fc,fac_D,pi_fc);
%     Cmax_fr = Single_DHNWFSP_SDST_Cmax(f_rand,fac_m,fac_r,fac_pij,fac_s,fr);
     [Cmax_fr,D_fr] = Speedup(f_rand,fac_m,fac_r,fac_pij,fac_s,fr,fac_D,pi_fr);
    if fac_Cmax(Crifac,1)>Cmax_fc&&fac_Cmax(Crifac,1)>Cmax_fr
          fac_pi{Crifac,1}=fc;
          fac_pi{f_rand,1}=fr;
          fac_Cmax(Crifac,1)=Cmax_fc;
          fac_Cmax(f_rand,1)=Cmax_fr;
          fac_D{Crifac,1}=D_fc;
          fac_D{f_rand,1}=D_fr;
%           Q_table(3,2)=Q_table(3,2)+aw;    
          Q_table(3,3)=Q_table(3,3)+1; 
    else
%         if Q_table(3,2)>0
%            Q_table(3,2)=Q_table(3,2)-pun;
%         end
        Q_table(3,4)=Q_table(3,4)+1; 
    end
    Q_table(3,2)=Q_table(3,2)+Q_table(3,3)/(Q_table(3,3)+Q_table(3,4));   
end

