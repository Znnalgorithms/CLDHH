function select_Q=Selection(Q_table)
    r=rand;
    P=zeros(1,size(Q_table,1));
    Q_sum=sum(sum(Q_table(:,2)));
    for i=1:size(Q_table,1)
        P(1,i)=Q_table(i,2)/Q_sum;
    end
    C=cumsum(P);
    select_Q=find(r<=C,1,'first');
end