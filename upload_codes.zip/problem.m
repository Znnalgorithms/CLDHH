function [Cmax,D_f] = problem(f_num,fac_m,fac_r,fac_pij,fac_s,pi)
D_f=zeros(size(pi,2),size(pi,2)+1);       %D��ֵ
pij=fac_pij{f_num,1};
S_f=fac_s{f_num,1};
m=fac_m{f_num,1};
for j=1:size(pi,2)
    calculate_max=zeros(m,1);
    if j==1
       for i=1:m
           current_sum=0;
           for h=i:m
               current_sum=current_sum+(pij(h,pi(1,j)));
           end
           s=S_f{i,1};
           calculate_max(i,1)=current_sum+s(1,pi(1,j));
       end
       D_f(j,j+1)=max(calculate_max);
    else
       for i=1:m
           current_sum=0;
           for h=i:m
               current_sum=current_sum+(pij(h,pi(1,j))-pij(h,pi(1,j-1)));
           end
           s=S_f{i,1};
           calculate_max(i,1)=current_sum+pij(i,pi(j-1))+s(pi(j-1)+1,pi(j));
       end
       D_f(j,j+1)=max(calculate_max);
     end
end
Cmax=fac_r{f_num,1};
for j=1:size(pi,2)
    Cmax=Cmax+D_f(j,j+1);
end
end







