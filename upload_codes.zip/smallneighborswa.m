function [fac_pi,fac_Cmax,fac_D,Q_table] = smallneighborswa(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table)
    Crifac=floor(f*rand)+1;
    pi_f=fac_pi{Crifac,1};
    fc=pi_f;
    if size(fc,2)~=1
       k_position=floor(size(fc,2)*rand)+1;
       j_position=floor(size(fc,2)*rand)+1;
       while j_position==k_position
          j_position=floor(size(fc,2)*rand)+1;
       end
       k=fc(1,k_position);
       j=fc(1,j_position);
       fc(1,k_position)=j;
       fc(1,j_position)=k;
%        j_position
%        k_position
%        fc
%        Cmax = Single_DHNWFSP_SDST_Cmax(Crifac,fac_m,fac_r,fac_pij,fac_s,fc);
       [Cmax,D_f] = Speedup(Crifac,fac_m,fac_r,fac_pij,fac_s,fc,fac_D,pi_f);
%        fac_Cmax(Crifac,1)
%        Cmax
       if fac_Cmax(Crifac,1)>Cmax
          fac_pi{Crifac,1}=fc;
          fac_Cmax(Crifac,1)=Cmax;
          fac_D{Crifac,1}=D_f;
%           Q_table(6,2)=Q_table(6,2)+aw;
          Q_table(6,3)=Q_table(6,3)+1;
       else
%           if Q_table(6,2)>0
%              Q_table(6,2)=Q_table(6,2)-pun;
%           end
          Q_table(6,4)=Q_table(6,4)+1;
       end
       Q_table(6,2)=Q_table(6,2)+Q_table(6,3)/(Q_table(6,3)+Q_table(6,4));  
    end
end

