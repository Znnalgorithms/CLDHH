function [fac_pi,fac_Cmax,fac_D,Q_table] = hyperheuristic(k,f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table,b_length,ratio)
    if k==1
        [fac_pi,fac_Cmax,fac_D,Q_table] = Ins_in_Crifac(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table);
    end
    if k==2
        [fac_pi,fac_Cmax,fac_D,Q_table] = Swa_in_Crifac(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table);
    end
    if k==3
        [fac_pi,fac_Cmax,fac_D,Q_table] = Swa_bet_Crifac(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table);
    end
    if k==4
        [fac_pi,fac_Cmax,fac_D,Q_table] = Ins_bet_Crifac(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table);
    end
    if k==5
        [fac_pi,fac_Cmax,fac_D,Q_table] = smallneighborins(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table);
    end
    if k==6
        [fac_pi,fac_Cmax,fac_D,Q_table] = smallneighborswa(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table);
    end
    if k==7
        [fac_pi,fac_Cmax,fac_D,Q_table] = largeneighborswa(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table);
    end
    if k==8
        [fac_pi,fac_Cmax,fac_D,Q_table] = largeneighborins(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table);
    end
    if k==9
       [fac_pi,fac_Cmax,fac_D,Q_table] = pr(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,b_length,Q_table,ratio);
    end
    if k==10
       [fac_pi,fac_Cmax,fac_D,Q_table] = exploitation(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,b_length,Q_table,ratio);
    end
end

