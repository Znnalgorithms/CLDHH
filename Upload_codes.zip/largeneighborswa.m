function [fac_pi,fac_Cmax,fac_D,Q_table] = largeneighborswa(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table)
%     Crifac=floor(f*rand)+1;
%     f_rand=floor(f*rand)+1;
%     while f_rand==Crifac
%        f_rand=floor(f*rand)+1;
%     end
    a=floor(f*rand)+1;
    b=floor(f*rand)+1;
    while b==a
       b=floor(f*rand)+1;
    end
    if fac_Cmax(a,1)>=fac_Cmax(b,1)
         Crifac=a;
         f_rand=b;
    else
         Crifac=b;
         f_rand=a;
    end
    pi_fc=fac_pi{Crifac,1};
    fc=pi_fc;
    pi_fr=fac_pi{f_rand,1};
    fr=pi_fr;
%     fc
%     fr
    j_position=floor(size(fc,2)*rand)+1;
    k_position=floor(size(fr,2)*rand)+1;
%     j_position
%     k_position
    j=fc(1,j_position);
    k=fr(1,k_position);
    fc(1,j_position)=k;
    fr(1,k_position)=j;
%     fc
%     fr
%     Cmax_fc = Single_DHNWFSP_SDST_Cmax(Crifac,fac_m,fac_r,fac_pij,fac_s,fc);
     [Cmax_fc,D_fc] = Speedup(Crifac,fac_m,fac_r,fac_pij,fac_s,fc,fac_D,pi_fc);
%     Cmax_fr = Single_DHNWFSP_SDST_Cmax(f_rand,fac_m,fac_r,fac_pij,fac_s,fr);
     [Cmax_fr,D_fr] = Speedup(f_rand,fac_m,fac_r,fac_pij,fac_s,fr,fac_D,pi_fr);
    if fac_Cmax(Crifac,1)>Cmax_fc&&fac_Cmax(Crifac,1)>Cmax_fr
          fac_pi{Crifac,1}=fc;
          fac_pi{f_rand,1}=fr;
          fac_Cmax(Crifac,1)=Cmax_fc;
          fac_Cmax(f_rand,1)=Cmax_fr;
          fac_D{Crifac,1}=D_fc;
          fac_D{f_rand,1}=D_fr;
%           Q_table(7,2)=Q_table(7,2)+aw;    
          Q_table(7,3)=Q_table(7,3)+1;   
    else
%         if Q_table(7,2)>0
%            Q_table(7,2)=Q_table(7,2)-pun;
%         end
          Q_table(7,4)=Q_table(7,4)+1;   
    end
    Q_table(7,2)=Q_table(7,2)+Q_table(7,3)/(Q_table(7,3)+Q_table(7,4));   
end

