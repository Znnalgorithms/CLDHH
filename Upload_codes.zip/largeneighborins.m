function [fac_pi,fac_Cmax,fac_D,Q_table] = largeneighborins(f,fac_m,fac_r,fac_pij,fac_s,fac_pi,fac_Cmax,fac_D,Q_table)
    a=floor(f*rand)+1;
    b=floor(f*rand)+1;
    while b==a
       b=floor(f*rand)+1;
    end
    if fac_Cmax(a,1)>=fac_Cmax(b,1)
         Crifac=a;
         f_rand=b;
    else
         Crifac=b;
         f_rand=a;
    end
    Crifac_max=fac_Cmax(Crifac,1);
    pi_fc=fac_pi{Crifac,1};
    fc=pi_fc;
    if size(fc,2)>1
    pi_fr=fac_pi{f_rand,1};
    fr=pi_fr;
%     fc
%     fr
    j_position=floor(size(fc,2)*rand)+1;
%     j_position
    j=fc(1,j_position);
    for i=j_position:size(fc,2)-1
        fc(1,i)=fc(1,i+1);
    end
    fc(:,size(fc,2))=[];
    %Cmax_fc = problem(Crifac,fac_m,fac_r,fac_pij,fac_s,fc);
    [Cmax_fc,D_fc] = Speedup(Crifac,fac_m,fac_r,fac_pij,fac_s,fc,fac_D,pi_fc);
%     fc
%     Cmax_fc
    index=zeros(size(fr,2)+1,size(fr,2)+1);
    Cmax_index=zeros(size(fr,2)+1,1);
    min_fr_Cmax=inf;
    for index_i=1:size(fr,2)+1
        t=1;
        for index_j=1:size(fr,2)+1
            if index_i==index_j
               index(index_i,index_j)=j;
            else
               index(index_i,index_j)=fr(1,t);
               t=t+1;
            end
        end
        %Cmax_index(index_i,1) = problem(f_rand,fac_m,fac_r,fac_pij,fac_s,index(index_i,:));
        [Cmax_index(index_i,1),D_fr] = Speedup(f_rand,fac_m,fac_r,fac_pij,fac_s,index(index_i,:),fac_D,pi_fr);
        if Cmax_index(index_i,1)<=min_fr_Cmax
            min_fr_Cmax=Cmax_index(index_i,1);
            min_fr=index_i;
            min_D_fr=D_fr;
        end
    end
%     index
%     Cmax_index
    if min_fr_Cmax<Crifac_max
       fac_pi{Crifac,1}=fc;
       fac_pi{f_rand,1}=index(min_fr,:);
       fac_Cmax(Crifac,1)=Cmax_fc;
       fac_Cmax(f_rand,1)=Cmax_index(min_fr,1);
          fac_D{Crifac,1}=D_fc;
          fac_D{f_rand,1}=min_D_fr;
%           Q_table(8,2)=Q_table(8,2)+aw;
          Q_table(8,3)=Q_table(8,3)+1;
    else
%         if Q_table(8,2)>0
%            Q_table(8,2)=Q_table(8,2)-pun;
%         end
        Q_table(8,4)=Q_table(8,4)+1;
    end
    Q_table(8,2)=Q_table(8,2)+Q_table(8,3)/(Q_table(8,3)+Q_table(8,4));   
    end
end
    

